document.querySelector('form').addEventListener('submit', function() {
    alert('Cadastro de Cuidador realizado com sucesso!'); // Altere isso conforme necessário
    window.location.href = '../php/listar_usuario.php'; // Substitua 'nova_pagina_cuidador.php' pelo nome real da sua nova página
});