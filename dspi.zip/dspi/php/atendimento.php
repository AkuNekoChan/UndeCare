<?php
session_start();

if (!isset($_SESSION['cuidador_id'])) {
    header("Location: ../html/login_cuidador.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dspi";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Recupera os parâmetros da URL
$cuidador_id = $_GET['cuidador_id'];
$usuario_id = $_GET['usuario_id'];

// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica se o índice 'status' está definido antes de acessá-lo
    $status = isset($_POST["status"]) ? $_POST["status"] : '';

    // Verifica se 'status' não está vazio antes de processar o SQL
    if (!empty($status)) {
        $sql = "INSERT INTO atendimento (status, cuidador_id, usuario_id) VALUES ('$status', '$cuidador_id', '$usuario_id')";

        if ($conn->query($sql) === TRUE) {
            echo "Atendimento criado com sucesso!";
        } else {
            echo "Erro ao criar o atendimento: " . $conn->error;
        }
    } else {
        echo "Status não pode ser vazio.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de Atendimento para Cuidadores</title>
    <link rel="stylesheet" href="../css/atendimento.css">
</head>
<body>

    <header>
        <h1>Tela de Atendimento para Cuidadores</h1>
    </header>

    <div class="container">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?cuidador_id=<?php echo $cuidador_id; ?>&usuario_id=<?php echo $usuario_id; ?>">
            <label for="status">Status:</label>
            <select id="status" name="status">
                <option value="disponivel">disponivel</option>
                <option value="indisponivel">indisponivel</option>
            </select>

            <button type="submit">Salvar Atendimento</button>
        </form>
    </div>

</body>
</html>
