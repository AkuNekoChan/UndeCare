<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dspi";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Consulta SQL para obter todos os idosos cadastrados
$sql = "SELECT * FROM ficha_idoso";
$result = $conn->query($sql);

// Fecha a conexão com o banco de dados
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Idosos Cadastrados</title>
    <link rel="stylesheet" href="../css/listar_idoso.css">
    
</head>
<body>
    <h2>Lista de Idosos Cadastrados</h2>
    <?php
    if ($result->num_rows > 0) {
        echo '<table>';
        echo '<tr><th>Nome do Idoso</th><th>CPF do Idoso</th><th>Data de Nascimento</th><th>Quadro Médico</th></tr>';

        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row["nome_idoso"] . '</td>';
            echo '<td>' . $row["cpf_idoso"] . '</td>';
            echo '<td>' . $row["data_nascimento"] . '</td>';
            echo '<td>' . $row["quadro_medico"] . '</td>';
            echo '</tr>';
        }

        echo '</table>';
    } else {
        echo '<div class="message">Nenhum idoso cadastrado.</div>';
    }
    ?>
</body>
</html>
