<?php
session_start();

if (!isset($_SESSION['cuidador_id'])) {
    // Se não estiver autenticado, redireciona para a página de login do cuidador
    header("Location: ../html/login_cuidador.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dspi";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_GET["usuario_id"];

$sqlUsuario = "SELECT * FROM usuario WHERE id = $user_id";
$resultUsuario = $conn->query($sqlUsuario);

if ($resultUsuario->num_rows > 0) {
    $usuario = $resultUsuario->fetch_assoc();
} else {
    header("Location: outra_pagina.php");
    exit();
}

$sqlFichaIdoso = "SELECT * FROM ficha_idoso WHERE usuario_id = $user_id";
$resultFichaIdoso = $conn->query($sqlFichaIdoso);

if ($resultFichaIdoso->num_rows > 0) {
    $fichaIdoso = $resultFichaIdoso->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil do Usuário</title>
    <link rel="stylesheet" href="../css/perfil_usuario.css">
</head>
<body>

    <header>
        <?php
        if (isset($_SESSION['cuidador_id'])) {
            $cuidador_id = $_SESSION['cuidador_id'];
            $sqlCuidador = "SELECT nome FROM cuidador WHERE id = $cuidador_id";
            $resultCuidador = $conn->query($sqlCuidador);

            if ($resultCuidador && $resultCuidador->num_rows > 0) {
                $cuidador = $resultCuidador->fetch_assoc();
                echo "<p>Olá, " . $cuidador['nome'] . "!</p>";

                if (isset($cuidador['foto_cuidador'])) {
                    echo "<img src='../img/cuidadores/" . $cuidador['foto_cuidador'] . "' alt='Foto do cuidador'>";
                }

                echo "<br>";
                echo "<a href='../php/logout.php'>Logout</a>";
                // Adicionando o link para a página de atendimento com parâmetros
                echo "<br>";
                echo "<a href='../php/atendimento.php?cuidador_id=$cuidador_id&usuario_id=$user_id'>Ir para a Página de Atendimento</a>";
            }
        }
        ?>
        <h1>Perfil do Usuário</h1>
    </header>

    <div class="container">
        <div class="perfil">
            <h2>Perfil do Usuário</h2>
            <p><strong>Nome:</strong> <?php echo $usuario["nome"]; ?></p>
            <p><strong>Sobrenome:</strong> <?php echo $usuario["sobrenome"]; ?></p>
            <p><strong>Telefone:</strong> <?php echo $usuario["telefone"]; ?></p>
            <p><strong>Email:</strong> <?php echo $usuario["email_usuario"]; ?></p>
        </div>

        <div class="ficha-idoso">
            <h2>Ficha do Idoso</h2>
            <?php if (isset($fichaIdoso)) : ?>
                <p><strong>Nome do Idoso:</strong> <?php echo $fichaIdoso["nome_idoso"]; ?></p>
                <p><strong>Data de Nascimento:</strong> <?php echo date('d/m/Y', strtotime($fichaIdoso["data_nascimento"])); ?></p>
                <p><strong>Quadro Médico:</strong> <?php echo $fichaIdoso["quadro_medico"]; ?></p>
            <?php else : ?>
                <p>Nenhuma ficha encontrada para este usuário.</p>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>

<?php
$conn->close();
?>
