<?php
// Inicia a sessão para usar a variável de mensagem
session_start();

// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dspi";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Mensagem de sucesso ou erro após a submissão do formulário
$message = "";

// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Dados do usuário a serem inseridos
    $nomeUsuario = $_POST['nome'];
    $sobrenomeUsuario = $_POST['sobrenome'];
    $emailUsuario = $_POST['email'];
    $cpfUsuario = $_POST['cpf'];
    $telefoneUsuario = $_POST['telefone'];
    $cidadeUsuario = $_POST['cidade'];
    $senhaUsuario = $_POST['senha'];

    // Processa o upload da foto do usuário
    $fotoDirUsuario = "../img/usuarios/";
    $fotoPathUsuario = $fotoDirUsuario . basename($_FILES["foto_usuario"]["name"]);
    
    if (move_uploaded_file($_FILES["foto_usuario"]["tmp_name"], $fotoPathUsuario)) {
        // SQL para inserir um novo usuário com foto
        $sqlUsuario = "INSERT INTO usuario (nome,sobrenome, email_usuario, cpf, telefone, cidade, senha, foto_usuario) VALUES ('$nomeUsuario', '$sobrenomeUsuario', '$emailUsuario', '$cpfUsuario', '$telefoneUsuario', '$cidadeUsuario', '$senhaUsuario', '$fotoPathUsuario')";
        
        // Executa a consulta SQL
        if ($conn->query($sqlUsuario) === TRUE) {
            $message = "Usuário adicionado com sucesso!";
            header("Location: ../html/inserir_idoso.html");
        } else {
            $message = "Erro ao adicionar usuário: " . $conn->error;
        }
    } else {
        $message = "Falha ao fazer o upload da foto do usuário.";
    }
}

// Fecha a conexão com o banco de dados
$conn->close();
?>