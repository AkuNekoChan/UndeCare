<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dspi";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Inicializa as variáveis
$email = $password = "";
$emailErr = $passwordErr = "";
$loginError = "";

// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica se o campo de email está preenchido
    if (empty($_POST["email"])) {
        $emailErr = "Email é obrigatório";
    } else {
        $email = $_POST["email"];
    }

    // Verifica se o campo de senha está preenchido
    if (empty($_POST["senha"])) {
        $passwordErr = "Senha é obrigatória";
    } else {
        $password = $_POST["senha"];
    }

    // Se não houver erros, realiza a autenticação
    if (empty($emailErr) && empty($passwordErr)) {
        // Verifica se o usuário existe na tabela usuario
        $sqlUsuario = "SELECT * FROM usuario WHERE email_usuario = '$email' AND senha = '$password'";
        $resultUsuario = $conn->query($sqlUsuario);

        // Se o usuário for encontrado, redireciona para a página do usuário
        if ($resultUsuario->num_rows > 0) {
            // Inicia a sessão
            session_start();

            // Obtém os dados do usuário
            $usuario = $resultUsuario->fetch_assoc();

            // Armazena o ID do usuário na sessão
            $_SESSION['user_id'] = $usuario['id'];

            // Redireciona para a página do usuário
            header("Location: ../php/listar_cuidador.php");
            exit();
        }

        // Verifica se o cuidador existe na tabela cuidador
        $sqlCuidador = "SELECT * FROM cuidador WHERE email_cuidador = '$email' AND senha = '$password'";
        $resultCuidador = $conn->query($sqlCuidador);

        // Se o cuidador for encontrado, redireciona para a página do cuidador
        if ($resultCuidador->num_rows > 0) {
            // Inicia a sessão
            session_start();

            // Obtém os dados do cuidador
            $cuidador = $resultCuidador->fetch_assoc();

            // Armazena o ID do cuidador na sessão
            $_SESSION['cuidador_id'] = $cuidador['id'];

            // Redireciona para a página do cuidador
            header("Location: ../php/buscar_usuario.php");
            exit();
        }

        // Se nenhum usuário ou cuidador for encontrado, exibe mensagem de erro
        $loginError = "Email ou senha incorretos";
    }
}

// Fecha a conexão com o banco de dados
$conn->close();
?>