login usuario php
<?php
session_start();

// Conexão com o banco de dados (certifique-se de ajustar as configurações conforme necessário)
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "dspi";

$conexao = new mysqli($servidor, $usuario, $senha, $banco);

if ($conexao->connect_error) {
    die("Erro de conexão: " . $conexao->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cpf = $_POST["cpf"];
    $senha = $_POST["senha"];

    // Consulta para verificar o usuário e senha no banco de dados
    $sql = "SELECT * FROM usuario WHERE cpf = '$cpf' AND senha = '$senha'";
    $resultado = $conexao->query($sql);

    if ($resultado->num_rows == 1) {
        // Login bem-sucedido, redirecionar para a página de lista_cuidadores.php
        $_SESSION["usuario_cpf"] = $cpf;
        header("Location: ../php/listar_cuidador.php");
        exit();
    } else {
        // Login falhou, exibir mensagem de erro
        echo "Login falhou. Verifique seu CPF e senha.";
    }
}

// Fechar a conexão
$conexao->close();
?>