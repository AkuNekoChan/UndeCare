<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/listar_usuario.css">
    <title>Lista de Usuários</title>
</head>
<body>

<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dspi";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

// Verifica se o usuário está autenticado
if (!isset($_SESSION['cuidador_id'])) {
    // Se não estiver autenticado, redireciona para a página de login
    header("Location: ../html/login_cuidador.html");
    exit();
}

$cuidador_id = $_SESSION['cuidador_id'];
$sqlCuidador = "SELECT * FROM cuidador WHERE id = $cuidador_id";
$resultCuidador = $conn->query($sqlCuidador);
$rowCuidador = $resultCuidador->fetch_assoc();

// Exibe o cabeçalho com nome e foto do usuário
echo "<header class='header'>";
echo "<div class='user-info'>";
echo "<img src='" . $rowCuidador["foto_cuidador"] . "' alt='Foto do cuidador' class='user-photo'>";
echo "<h2>Bem-vindo, " . $rowCuidador['nome'] . "!</h2>";
echo "</div>";
echo "<a href='../php/logout.php'>Sair</a>";
echo "</header>";
?>

<h2>Lista de Usuários</h2>

<?php
// SQL para selecionar todos os usuários
$sqlUsuarios = "SELECT * FROM usuario";
$resultUsuarios = $conn->query($sqlUsuarios);

if ($resultUsuarios->num_rows > 0) {
    // Exibe os usuários em uma tabela
    echo "<table>";
    echo "<tr><th>ID</th><th>Nome</th><th>Email</th><th>CPF</th><th>Telefone</th><th>Cidade</th><th>Foto</th></tr>";
    
    while ($row = $resultUsuarios->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["nome"] . "</td>";
        echo "<td>" . $row["email_usuario"] . "</td>";
        echo "<td>" . $row["cpf"] . "</td>";
        echo "<td>" . $row["telefone"] . "</td>";
        echo "<td>" . $row["cidade"] . "</td>";
        echo "<td><img src='" . $row["foto_usuario"] . "' alt='Foto do Usuário' class='user-photo'></td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "Nenhum usuário cadastrado.";
}

// Fecha a conexão com o banco de dados
$conn->close();
?>

</body>
</html>


