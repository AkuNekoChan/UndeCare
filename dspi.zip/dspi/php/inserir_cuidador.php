<?php
// Configurações do banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dspi";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Processamento do formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $sobrenomeCuidador = $_POST['sobrenome'];
    $email_cuidador = $_POST["email_cuidador"];
    $telefone = $_POST["telefone"];
    $cpf = $_POST["cpf"];
    $pdf = $_FILES["pdf"]["name"];
    $fale_sobre = $_POST["fale_sobre"];
    $area_atuacao = $_POST["area_atuacao"];
    $cidade = $_POST["cidade"];
    $dia_inicio = $_POST["dia_inicio"];
    $dia_fim = $_POST["dia_fim"];
    $periodo = $_POST["periodo"];
    $senha = $_POST["senha"];

    // Processamento do upload de PDF
    $pdf_tmp = $_FILES["pdf"]["tmp_name"];
    move_uploaded_file($pdf_tmp, "../pdf/".$pdf);

    // Processamento do upload de imagem
    $foto_cuidador = $_FILES["foto_cuidador"]["name"];
    $foto_cuidador_tmp = $_FILES["foto_cuidador"]["tmp_name"];
    move_uploaded_file($foto_cuidador_tmp, "../img/cuidadores/".$foto_cuidador);

    // Inserção de dados na tabela cuidador
    $sql = "INSERT INTO cuidador (nome,sobrenome, email_cuidador, telefone, cpf, pdf, fale_sobre, area_atuacao, cidade, dia_inicio, dia_fim, periodo, senha, foto_cuidador) VALUES ('$nome','$sobrenomeCuidador', '$email_cuidador', '$telefone', '$cpf', '$pdf', '$fale_sobre', '$area_atuacao', '$cidade', '$dia_inicio', '$dia_fim', '$periodo', '$senha', '$foto_cuidador')";

    if ($conn->query($sql) === TRUE) {
        // Cadastro realizado com sucesso, redirecionar para outra página
        header("Location: ../html/login_cuidador.html");
        exit(); // Certifique-se de sair após o redirecionamento
    } else {
        echo "Erro ao cadastrar: " . $conn->error;
    }
}
?>
