<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION["usuario_cpf"])) {
    header("Location: ../html/login_usuario.html");
    exit();
}

// Inclua o arquivo de conexão
$servername = "localhost";
$username = "root";
$password = "";
$banco = "dspi";

$conn = new mysqli($servername, $username, $password, $banco);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$cpf_usuario = $_SESSION["usuario_cpf"];
$sql_usuario = "SELECT * FROM usuario WHERE cpf = '$cpf_usuario'";
$resultado_usuario = $conn->query($sql_usuario);

if ($resultado_usuario->num_rows == 1) {
    $dados_usuario = $resultado_usuario->fetch_assoc();
    $nome_usuario = $dados_usuario["nome"];
    $foto_usuario = $dados_usuario["foto_usuario"];
} else {
    // Caso algo dê errado, redirecione para o login
    header("Location: ../html/login_usuario.html");
    exit();
}

// Lógica de pesquisa
$condicoes_pesquisa = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $termo_pesquisa = $_POST["termo_pesquisa"];
    $condicoes_pesquisa = "WHERE nome LIKE '%$termo_pesquisa%' OR telefone LIKE '%$termo_pesquisa%' OR area_atuacao LIKE '%$termo_pesquisa%' OR cidade LIKE '%$termo_pesquisa%'";
}

// Consulta para obter a lista de cuidadores com base nas condições de pesquisa
$sql_cuidadores = "SELECT * FROM cuidador $condicoes_pesquisa";
$resultado_cuidadores = $conn->query($sql_cuidadores);

// Fechar a conexão
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/listar.css">
    <title>Lista de Cuidadores</title>
</head>

<body>
    <div class="header">
        <div>
            <h2>Bem-vindo(a), <?php echo $nome_usuario; ?></h2>
            <img src="<?php echo $foto_usuario; ?>" alt="Foto do usuário">
        </div>
        <a href="../php/logout.php">Sair</a>
    </div>

    <div class="cuidadores-container">
        <h2>Lista de Cuidadores</h2>

        <!-- Formulário de pesquisa -->
        <form method="post">
            <label for="termo_pesquisa">Pesquisar por nome, telefone, área de atuação ou cidade:</label>
            <input type="text" id="termo_pesquisa" name="termo_pesquisa">
            <button type="submit">Pesquisar</button>
        </form>

        <div class="card-container">
            <?php
            while ($row = $resultado_cuidadores->fetch_assoc()) {
                echo "<a href='perfil_cuidador.php?id=" . $row['id'] . "' class='card'>";
                echo "<img src='../img/cuidadores/" . $row['foto_cuidador'] . "' alt='Foto do cuidador'>";
                echo "<h3>" . $row['nome'] . "</h3>";
                echo "<p>" . $row['fale_sobre'] . "</p>";
                echo "</a>";
            }
            ?>
        </div>
    </div>
</body>

</html>