<?php
session_start();
if (!isset($_SESSION['cuidador_id'])) {
    // Se não estiver autenticado, redireciona para a página de login do cuidador
    header("Location: ../html/login_cuidador.html");
    exit();
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dspi";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search_term = $_POST["search_term"];

    // Consulta para buscar o usuário por nome, telefone ou e-mail
    $sql = "SELECT * FROM usuario WHERE nome LIKE '%$search_term%' OR telefone LIKE '%$search_term%' OR email_usuario LIKE '%$search_term%'";
    $query_result = $conn->query($sql);

    if ($query_result->num_rows > 0) {
        while ($row = $query_result->fetch_assoc()) {
            $result[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Busca de Usuário</title>
    <link rel="stylesheet" href="../css/listar.css">
</head>
<body>

    <header>
       <?php
        // Verifica se o cuidador está autenticado
        if (isset($_SESSION['cuidador_id'])) {
            // Se estiver autenticado, exibe o nome e a foto do cuidador
            $cuidador_id = $_SESSION['cuidador_id'];
            $sqlCuidador = "SELECT nome, foto_cuidador FROM cuidador WHERE id = $cuidador_id";
            $resultCuidador = $conn->query($sqlCuidador);

            if ($resultCuidador && $resultCuidador->num_rows > 0) {
                $cuidador = $resultCuidador->fetch_assoc();
                echo "<p>Olá, " . $cuidador['nome'] . "!</p>";

                // Verifica se a chave 'foto_cuidador' existe antes de acessá-la
                if (isset($cuidador['foto_cuidador'])) {
                    echo "<img src='../img/cuidadores/" . $cuidador['foto_cuidador'] . "' alt='Foto do cuidador'>";
                }

                echo "<br>";
                echo "<a href='../php/logout.php'>sair</a>";
            }
        }
        ?>
        <h1>Busca de Usuário</h1>
    </header>

    <div class="container">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="search_term">Buscar por Nome, Telefone ou E-mail:</label>
            <input type="text" id="search_term" name="search_term" required>
            <button type="submit">Buscar</button>
        </form>

        <?php
        if (!empty($result)) {
            foreach ($result as $usuario) {
                echo "<div class='card'>";
                echo "<h2>" . $usuario["nome"] . "</h2>";
                echo "<p><strong>Telefone:</strong> " . $usuario["telefone"] . "</p>";
                echo "<p><strong>Email:</strong> " . $usuario["email_usuario"] . "</p>";
                 echo "<a href='../php/perfil_usuario.php?usuario_id=" . $usuario["id"] . "'>Ver detalhes</a>";
                echo "</div>";
            }
        } else {
            echo "<p>Nenhum resultado encontrado.</p>";
        }
        ?>
    </div>

<?php
// Agora, feche a conexão após usar os resultados da busca
$conn->close();
?>

</body>
</html>
