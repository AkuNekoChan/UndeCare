<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dspi";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Dados do formulário
$nomeIdoso = $_POST['nome_idoso'];
$cpfIdoso = $_POST['cpf_idoso'];
$dataNascimento = $_POST['data_nascimento'];
$quadroMedico = $_POST['quadro_medico'];
$cpfUsuario = $_POST['cpf_usuario'];

// Verifica se o usuário já existe no banco de dados
$sqlUsuario = "SELECT id FROM usuario WHERE cpf = '$cpfUsuario'";
$resultUsuario = $conn->query($sqlUsuario);

if ($resultUsuario->num_rows > 0) {
    // Usuário encontrado, continue com a inserção
    $rowUsuario = $resultUsuario->fetch_assoc();
    $usuarioId = $rowUsuario['id'];

    // Insira o idoso na tabela ficha_idoso
    $sqlFichaIdoso = "INSERT INTO ficha_idoso (nome_idoso, cpf_idoso, data_nascimento, quadro_medico, usuario_id) 
                      VALUES ('$nomeIdoso', '$cpfIdoso', '$dataNascimento', '$quadroMedico', '$usuarioId')";
    
    if ($conn->query($sqlFichaIdoso) === TRUE) {
        $message = "Ficha de idoso cadastrada com sucesso!";
        header("Location: ../html/login_usuario.html");
    } else {
        $message = "Erro ao inserir ficha de idoso: " . $conn->error;
    }
} else {
    $message = "Usuário não encontrado com o CPF fornecido.";
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
