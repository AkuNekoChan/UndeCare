<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listagem de Endereços</title>
    <style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    width: 80%;
    margin: auto;
    background: #fff;
    padding: 20px;
    margin-top: 50px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    color: #333;
}

.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.table th, .table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.table th {
    background-color: #4caf50;
    color: white;
}
</style>

</head>
<body>
    <div class="container">
        <h2>Listagem de Endereços</h2>

        <?php
        // Conecta ao banco de dados (substitua com suas credenciais)
        $servername = "localhost";
$username = "root";
$password = "";
$dbname = "dspi";

// Conexão com o banco de dados
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

        // Consulta SQL para obter dados da tabela endereco
        $sql = "SELECT * FROM endereco";
        $result = $conn->query($sql);

        // Verifica se há registros
        if ($result->num_rows > 0) {
            echo "<table class='table'>";
            echo "<tr>
                    <th>ID</th>
                    <th>Cidade</th>
                    <th>CEP</th>
                    <th>Bairro</th>
                    <th>Rua</th>
                    <th>Complemento</th>
                    <th>Número</th>
                    <th>Cuidador ID</th>
                </tr>";

            // Loop através dos resultados e exibe cada linha
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['cidade']}</td>
                        <td>{$row['cep']}</td>
                        <td>{$row['bairro']}</td>
                        <td>{$row['rua']}</td>
                        <td>{$row['complemento']}</td>
                        <td>{$row['numero']}</td>
                        <td>{$row['cuidador_id']}</td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "Nenhum resultado encontrado.";
        }

        // Fecha a conexão com o banco de dados
        $conn->close();
        ?>
    </div>
</body>
</html>
