<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION["usuario_cpf"])) {
    header("Location: ../html/login_usuario.html");
    exit();
}

// Inclua o arquivo de conexão
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dspi";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$cpf_usuario = $_SESSION["usuario_cpf"];
$sql_usuario = "SELECT * FROM usuario WHERE cpf = '$cpf_usuario'";
$resultado_usuario = $conn->query($sql_usuario);

if ($resultado_usuario->num_rows == 1) {
    $dados_usuario = $resultado_usuario->fetch_assoc();
    $nome_usuario = $dados_usuario["nome"];
    $foto_usuario = $dados_usuario["foto_usuario"];
} else {
    // Caso algo dê errado, redirecione para o login
    header("Location: ../html/login_usuario.html");
    exit();
}

// Obtenha o ID do cuidador a partir dos parâmetros da URL
$cuidadorId = isset($_GET['id']) ? $_GET['id'] : null;

// Verifique se o ID do cuidador foi fornecido
if ($cuidadorId) {
    // Consulta para obter os dados do cuidador
    $sql = "SELECT * FROM cuidador WHERE id = $cuidadorId";
    $result = $conn->query($sql);

    // Verifique se a consulta retornou resultados
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Exibir os detalhes do cuidador
        echo "<!DOCTYPE html>";
        echo "<html lang='en'>";
        echo "<head>";
        echo "<meta charset='UTF-8'>";
        echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
        echo "<link rel='stylesheet' href='../css/perfil.css'>";

        // Adicione seus estilos CSS aqui
        echo "<title>Perfil de {$row['nome']} {$row['sobrenome']}</title>";
        echo "</head>";
        echo "<body>";

        // Seção do cabeçalho
        echo "<div class='header'>";
        echo "<div>";
        echo "<h2>Bem-vindo, $nome_usuario</h2>";
        echo "<img src='$foto_usuario' alt='Foto do usuário'>";
        echo "</div>";
        echo "<a href='../php/logout.php'>Sair</a>";
        echo "</div>";

        // Seção de perfil do cuidador
        echo "<h1>Perfil de {$row['nome']} {$row['sobrenome']}</h1>";
        echo "<img src='../img/cuidadores/" . $row['foto_cuidador'] . "' alt='Foto do cuidador'>";
        echo "<p>Fale Sobre: {$row['fale_sobre']}</p>";
        echo "<p>Dias disponíveis:</p>";
        echo "<p>De {$row['dia_inicio']} a {$row['dia_fim']}</p>";
        echo "<p>Período: {$row['periodo']}</p>";
        echo "<p>Área de Atuação: {$row['area_atuacao']}</p>";
        echo "<p>Cidade: {$row['cidade']}</p>";

        // Link para abrir o WhatsApp com o número do cuidador
        echo "<p>Número de WhatsApp: <a href='https://api.whatsapp.com/send?phone={$row['telefone']}' target='_blank'>Enviar Mensagem</a></p>";
        echo "</body>";
        echo "</html>";
    } else {
        echo "Cuidador não encontrado.";
    }
} else {
    echo "ID do cuidador não fornecido.";
}

// Fechar a conexão com o banco de dados
$conn->close();
